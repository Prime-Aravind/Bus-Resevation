package com.shivajivarma.brs.ui;

/**
 * @author <a href="http://shivajivarma.com" target="_blank">Shivaji Varma</a>
 */
public interface View {
	public void refresh();
}