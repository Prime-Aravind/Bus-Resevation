package com.shivajivarma.brs.model;

/**
 * @author <a href="http://shivajivarma.com" target="_blank">Shivaji Varma</a>
 */
public interface Model{}