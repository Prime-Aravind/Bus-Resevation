package com.shivajivarma.brs.utility.constants;

/**
 * @author <a href="http://shivajivarma.com" target="_blank">Shivaji Varma</a>
 */
public class Fields {
	public static final String ID = "id";
}
