package Debug;

import com.shivajivarma.brs.utility.IOHelpers;

public class Debug {

	public static void main(String[] args) {
		//	System.out.println(new SimpleDateFormat("dd/MMM/yyyy").format(Calendar.getInstance().getTime()));
		IOHelpers.printHTML("fg", "test");
	}

}
