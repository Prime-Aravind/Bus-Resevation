Database Setup
==============

Create database user (You can create new user with custom username and password, but make sure you update the information of user in ```src/main/resources/spring-jdbc.xml```):
* username: admin
* password: admin

Please run sql scripts in following order:

1. setup.sql
2. data.sql
